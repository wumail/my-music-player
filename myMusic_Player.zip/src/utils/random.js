export function getRandom(n, m) {
    return parseInt(Math.random() * (m - n + 1) + n)
}