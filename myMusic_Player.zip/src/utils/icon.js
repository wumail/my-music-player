import loopIcon from '@/assets/icon/playerfull/icon_16/loop.png';
import singleIcon from '@/assets/icon/playerfull/icon_16/single.png';
import randomIcon from '@/assets/icon/playerfull/icon_16/random.png';
import playIcon from '@/assets/icon/playerfull/icon_48/play.png';
import pauseIcon from '@/assets/icon/playerfull/icon_48/pause.png';

export {
    loopIcon,
    singleIcon,
    randomIcon,
    playIcon,
    pauseIcon,
}