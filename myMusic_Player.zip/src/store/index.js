import { createStore } from "vuex";
import playerNsong from './modules/song';

export default createStore({
  state: {},
  mutations: {},
  actions: {},
  modules: {
    playerNsong,
  },
});