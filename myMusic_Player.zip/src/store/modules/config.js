export const playMode = {
    loop: 0,
    single: 1,
    random: 2,
}